<?php
function curl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
    curl_setopt($ch, CURLOPT_VERBOSE, true); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
    
    $output = curl_exec($ch);

    if (curl_errno($ch)) {
        echo 'Error cURL: ' . curl_error($ch); 
    }

    curl_close($ch);
    return $output;

}
$send = curl("https://localhost/rekayasaweb/pertemuan2/getwisata.php");
$data = json_decode($send, TRUE);

foreach($data as $row){
    echo $row["id"]. "<br/>";
    echo $row["kota"]. "<br/>";
    echo $row["landmark"]. "<br/>";
    echo $row["tarif"]."<br/><hr/>";
    
}
?>

