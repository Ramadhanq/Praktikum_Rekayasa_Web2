<?php
$cars = array("volvo","bmw","toyota");

echo json_encode($cars);
?>