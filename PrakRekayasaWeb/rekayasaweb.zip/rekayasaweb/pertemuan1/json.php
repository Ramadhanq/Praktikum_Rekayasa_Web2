<?php
$age = array("peter"=>35, "ben"=>37,"joe=>43");

echo json_encode($age);

?>