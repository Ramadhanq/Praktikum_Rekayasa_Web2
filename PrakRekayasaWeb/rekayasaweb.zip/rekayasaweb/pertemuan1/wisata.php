<?php
$jsonobj='{"peter":35,"ben":37,"joe":43}';
$obj = json_decode($jsonobj);

echo $obj->peter;
echo $obj->ben;
echo $obj->joe;

?>
